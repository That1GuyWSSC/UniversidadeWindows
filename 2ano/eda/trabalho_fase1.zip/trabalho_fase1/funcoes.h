

void printlistamaq(struct maquina* insert);
void insertop(struct operacoes** head, int numero);
void printlistaop(struct operacoes* head);