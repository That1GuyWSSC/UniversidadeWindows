extern int maiorValorPar(int array[], int n);
extern int valoresSuperiores(int array[], int n);
extern int verificaPar(int n);
extern int mostrarArrayInvertido(int array[], int n);