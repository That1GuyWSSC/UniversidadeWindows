#include "main.c"

bool registaVacinado(tVacinado p, tVacinado v[], int *n){

    

} 