
typedef enum {false, true} bool;

extern bool registaVacinado(tVacinado p, tVacinado v[], int *n);
