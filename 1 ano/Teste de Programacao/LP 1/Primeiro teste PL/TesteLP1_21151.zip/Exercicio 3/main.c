#include <stdio.h>
#include <stdlib.h>
#include "Dados.h"

typedef struct 
{
    char nome[50];
    char localidade[20];
    int idade;

}tVacinado; 


int main(){