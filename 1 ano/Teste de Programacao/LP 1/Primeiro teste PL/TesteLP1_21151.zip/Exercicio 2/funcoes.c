int maiorValorPar(int array[], int n){
    int aux;
    for (int i = 0; i < n; i++)
    {
        if (array[i] != (array[i] /2 == 0))
        {
            array[i]= aux;
            return aux;
        }
        
    }
    

}


int mostrarArrayInvertido(int array[], int n){
    int aux;
    for (int i = n -1 ; i >=0; i--)
    {
       aux = array[i];
       return aux;
    }
    

}