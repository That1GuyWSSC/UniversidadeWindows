extern int maiorValorPar(int array[], int n);
extern int mostrarArrayInvertido(int array[], int n);